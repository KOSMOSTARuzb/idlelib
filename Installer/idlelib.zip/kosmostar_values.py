number_of_chars = 4
f7_title = "Save & Run..."
f8_title = "Restore & Run..."
max_bytes_to_transfer = 51200 #50KB
null = 'Null'
port = 65432
connection_timeout = 2.0 # Used to scan sebnetwork(in seconds)
max_threads = 50 # Maximum number of paralel proccesses when scanning