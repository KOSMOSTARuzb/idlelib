
f7_title = "Save & Run..."
f8_title = "Restore & Run..."
max_bytes_to_transfer = 51200 #50KB
null = 'Null'
host = '192.168.25.171'
port = 65432